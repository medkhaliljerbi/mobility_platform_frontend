import { Routes } from '@angular/router';
import { AppLayout } from './app/layout/component/app.layout';
import { Dashboard } from './app/pages/dashboard/dashboard';
import { Documentation } from './app/pages/documentation/documentation';
import { Landing } from './app/pages/landing/landing';
import { Notfound } from './app/pages/notfound/notfound';
import { EnsureStudentSetupGuard } from './app/core/guards/ensure-student-setup.guard';

export const appRoutes: Routes = [
  {
    path: '',
    component: AppLayout,
    // ✅ Guard applies to ALL children, but it will ALLOW /student/setup
    canActivateChild: [EnsureStudentSetupGuard],
    children: [
      // Onboarding (allowed by guard)
      {
        path: 'student/setup',
        loadComponent: () =>
          import('./app/pages/student/profile-setup').then((m) => m.StudentProfileSetupComponent),
      },

      { path: '', component: Dashboard },
      { path: 'uikit', loadChildren: () => import('./app/pages/uikit/uikit.routes') },
      { path: 'documentation', component: Documentation },
      { path: 'pages', loadChildren: () => import('./app/pages/pages.routes') },
    ],
  },

  // Auth area is OUTSIDE the guarded layout and always reachable
  { path: 'landing', component: Landing },
  { path: 'notfound', component: Notfound },
  { path: 'auth', loadChildren: () => import('./app/pages/auth/auth.routes') },
  { path: '**', redirectTo: '/notfound' },
];
