import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { StudentSelfService, StudentSelfView, StudentSelfUpdate } from '@/core/services/student-self.service';
import { EnumsService } from '@/core/services/enums.service';

// PrimeNG / Sakai (Angular 20 / PrimeNG 20)
import { CardModule } from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { SelectModule } from 'primeng/select';
import { DatePickerModule } from 'primeng/datepicker';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-student-profile-setup',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    HttpClientModule,
    CardModule,
    ButtonModule,
    InputTextModule,
    SelectModule,
    DatePickerModule,
    ToastModule
  ],
  providers: [MessageService],
  template: `
  <div class="min-h-screen p-4 md:p-6 bg-surface-50 dark:bg-surface-950">
    <div class="mx-auto max-w-5xl">
      <p-card class="shadow-lg rounded-2xl">
        <ng-template pTemplate="title">
          <div class="flex items-center justify-between">
            <span class="text-xl font-semibold">Complete your profile (Étudiant sortant)</span>
            <button pButton type="button" label="Save" icon="pi pi-check"
                    class="p-button-success"
                    (click)="onSubmit()" [disabled]="form.invalid || saving()"></button>
          </div>
        </ng-template>

        <div class="grid grid-cols-12 gap-4">
          <!-- Identity (read-only) -->
          <div class="col-span-12">
            <div class="grid grid-cols-12 gap-3">
              <div class="col-span-12 md:col-span-4">
                <label class="text-sm text-muted-color">Esprit Email</label>
                <input pInputText [value]="model()?.email ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-4">
                <label class="text-sm text-muted-color">Esprit ID</label>
                <input pInputText [value]="model()?.studentIdentifier ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-4">
                <label class="text-sm text-muted-color">Type</label>
                <input pInputText [value]="typeLabel()" readonly class="w-full" />
              </div>

              <div class="col-span-12 md:col-span-4">
                <label class="text-sm text-muted-color">First Name</label>
                <input pInputText [value]="model()?.firstName ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-4">
                <label class="text-sm text-muted-color">Middle Name</label>
                <input pInputText [value]="model()?.middleName ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-4">
                <label class="text-sm text-muted-color">Last Name</label>
                <input pInputText [value]="model()?.lastName ?? ''" readonly class="w-full" />
              </div>
            </div>
          </div>

          <!-- User editable -->
          <div class="col-span-12">
            <div class="grid grid-cols-12 gap-3">
              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Personal Email</label>
                <input pInputText formControlName="emailPersonnel" class="w-full" placeholder="example@mail.com" />
              </div>
              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Marital Status</label>
                <input pInputText formControlName="maritalStatus" class="w-full" placeholder="single / married / ..." />
              </div>

              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Phone (Personal) *</label>
                <input pInputText formControlName="personnelPhoneNumber" class="w-full" placeholder="+216 ..." />
              </div>
              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Phone (Home)</label>
                <input pInputText formControlName="domicilePhoneNumber" class="w-full" />
              </div>
            </div>
          </div>

          <!-- Avatar (upload + preview) -->
          <div class="col-span-12">
            <div class="grid grid-cols-12 gap-3 items-end">
              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Avatar Preview</label>
                <div class="flex items-center gap-3">
                  <img [src]="avatarUrlPreview()" alt="avatar"
                       class="w-24 h-24 rounded-full object-cover border" (error)="imgFallback($event)" />
                  <span class="text-sm text-muted-color">{{ avatarUrlPreview() || 'No avatar yet' }}</span>
                </div>
              </div>
              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Upload New Photo</label>
                <input type="file" accept="image/*" (change)="onAvatarSelected($event)" class="w-full" />
                <small class="text-xs text-muted-color">PNG/JPG/WEBP. Upload saves immediately.</small>
              </div>
            </div>
          </div>

          <!-- Esprit Enrollment (SORTANT) -->
          <div class="col-span-12">
            <div class="grid grid-cols-12 gap-3">
              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Department</label>
                <p-select formControlName="department"
                          [options]="departmentOptions()"
                          optionLabel="label" optionValue="value"
                          class="w-full"></p-select>
              </div>

              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Speciality</label>
                <p-select formControlName="speciality"
                          [options]="specialityOptions()"
                          optionLabel="label" optionValue="value"
                          class="w-full"></p-select>
              </div>

              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Current Class</label>
                <input pInputText formControlName="currentClass" class="w-full" placeholder="e.g., 4GL-A" />
              </div>

              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Entry Date</label>
                <p-datepicker formControlName="entryDate" dateFormat="yy-mm-dd" [showIcon]="true" class="w-full"></p-datepicker>
              </div>

              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Expected Exit Date</label>
                <p-datepicker formControlName="expectedExitDate" dateFormat="yy-mm-dd" [showIcon]="true" class="w-full"></p-datepicker>
              </div>
            </div>
          </div>

          <div class="col-span-12 flex justify-end gap-2 mt-2">
            <button pButton type="button" label="Cancel" class="p-button-secondary" routerLink="/"></button>
            <button pButton type="button" label="Save" icon="pi pi-check" class="p-button-success"
                    (click)="onSubmit()" [disabled]="form.invalid || saving()"></button>
          </div>
        </div>
      </p-card>
    </div>
  </div>

  <p-toast></p-toast>
  `
})
export class StudentProfileSetupComponent implements OnInit {
  private fb = inject(FormBuilder);
  private api = inject(StudentSelfService);
  private enums = inject(EnumsService);
  private messages = inject(MessageService);

  model = signal<StudentSelfView | null>(null);
  saving = signal(false);

  departmentOptions = signal<{label:string; value:string}[]>([]);
  specialityOptions = signal<{label:string; value:string}[]>([]);

  form = this.fb.group({
    // user editable
    emailPersonnel: [''],
    maritalStatus: [''],
    personnelPhoneNumber: ['', Validators.required],
    domicilePhoneNumber: [''],

    // esprit enrollment
    department: [''],
    speciality: [''],
    currentClass: [''],
    entryDate: <Date | null>(null),
    expectedExitDate: <Date | null>(null),
  });

  ngOnInit(): void {
    // load enums
    this.enums.getFieldOptions().subscribe({
      next: opts => this.departmentOptions.set(opts),
      error: err => this.toastErr('Enums (Field) failed', err)
    });
    this.enums.getOptionCodeOptions().subscribe({
      next: opts => this.specialityOptions.set(opts),
      error: err => this.toastErr('Enums (OptionCode) failed', err)
    });

    // load model
    this.api.getMe().subscribe({
      next: (res) => {
        this.model.set(res);
        this.form.patchValue({
          emailPersonnel: res.emailPersonnel ?? '',
          maritalStatus: res.maritalStatus ?? '',
          personnelPhoneNumber: res.personnelPhoneNumber ?? '',
          domicilePhoneNumber: res.domicilePhoneNumber ?? '',
          department: res.department ?? '',
          speciality: res.speciality ?? '',
          currentClass: res.currentClass ?? '',
          entryDate: res.entryDate ? new Date(res.entryDate) : null,
          expectedExitDate: res.expectedExitDate ? new Date(res.expectedExitDate) : null
        });
      },
      error: (err) => this.toastErr('Load failed', err)
    });
  }

  typeLabel = computed(() => 'SORTANT');
  avatarUrlPreview = computed(() => this.model()?.avatarUrl || '');

  imgFallback(ev: any) { ev.target.style.display = 'none'; }

  onAvatarSelected(ev: Event) {
    const input = ev.target as HTMLInputElement;
    const file = input?.files?.[0];
    if (!file) return;

    this.saving.set(true);
    this.api.uploadAvatar(file).subscribe({
      next: () => {
        // refresh model to get new presigned avatarUrl
        this.api.getMe().subscribe({
          next: (m) => {
            this.model.set(m);
            this.saving.set(false);
            this.messages.add({ severity: 'success', summary: 'Avatar', detail: 'Photo uploaded' });
          },
          error: (err) => {
            this.saving.set(false);
            this.toastErr('Refresh failed', err);
          }
        });
      },
      error: (err) => {
        this.saving.set(false);
        this.toastErr('Upload failed', err);
      }
    });
  }

  onSubmit() {
    if (this.form.invalid) return;
    this.saving.set(true);

    const v = this.form.value;
    const payload: StudentSelfUpdate = {
      emailPersonnel: v.emailPersonnel ?? null,
      maritalStatus: v.maritalStatus ?? null,
      personnelPhoneNumber: v.personnelPhoneNumber ?? null,
      domicilePhoneNumber: v.domicilePhoneNumber ?? null,
      department: v.department ?? null,
      speciality: v.speciality ?? null,
      currentClass: v.currentClass ?? null,
      entryDate: v.entryDate ? this.toYmd(v.entryDate as Date) : null,
      expectedExitDate: v.expectedExitDate ? this.toYmd(v.expectedExitDate as Date) : null
    };

    this.api.updateMe(payload).subscribe({
      next: (res) => {
        this.model.set(res);
        this.saving.set(false);
        this.messages.add({ severity: 'success', summary: 'Saved', detail: 'Profile updated' });
      },
      error: (err) => {
        this.saving.set(false);
        this.toastErr('Save failed', err);
      }
    });
  }

  private toYmd(d: Date): string {
    const y = d.getFullYear();
    const m = (d.getMonth() + 1).toString().padStart(2, '0');
    const day = d.getDate().toString().padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  private toastErr(summary: string, err: any) {
    const detail = err?.error?.message || err?.message || 'Unexpected error';
    this.messages.add({ severity: 'error', summary, detail });
  }
}
