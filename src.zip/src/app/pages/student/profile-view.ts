import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { StudentSelfService, StudentSelfView } from '@/core/services/student-self.service';

// PrimeNG (v20)
import { CardModule } from 'primeng/card';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-student-profile-view',
  standalone: true,
  imports: [CommonModule, RouterModule, HttpClientModule, CardModule, ButtonModule, InputTextModule, ToastModule],
  providers: [MessageService],
  template: `
  <div class="min-h-screen p-4 md:p-6 bg-surface-50 dark:bg-surface-950">
    <div class="mx-auto max-w-5xl">
      <p-card class="shadow-lg rounded-2xl">
        <ng-template pTemplate="title">
          <div class="flex items-center justify-between">
            <span class="text-xl font-semibold">My Profile</span>
            <button pButton type="button" label="Edit" icon="pi pi-pencil" class="p-button-primary" routerLink="/student/setup"></button>
          </div>
        </ng-template>

        <div class="grid grid-cols-12 gap-4">
          <!-- Avatar -->
          <div class="col-span-12 md:col-span-4">
            <img [src]="avatarUrl()" alt="avatar" class="w-40 h-40 rounded-full object-cover border" (error)="imgFallback($event)" />
          </div>

          <!-- Identity -->
          <div class="col-span-12 md:col-span-8">
            <div class="grid grid-cols-12 gap-3">
              <div class="col-span-12 md:col-span-6">
                <label class="text-sm text-muted-color">Esprit Email</label>
                <input pInputText [value]="m()?.email ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-6">
                <label class="text-sm text-muted-color">Esprit ID</label>
                <input pInputText [value]="m()?.studentIdentifier ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-4">
                <label class="text-sm text-muted-color">First</label>
                <input pInputText [value]="m()?.firstName ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-4">
                <label class="text-sm text-muted-color">Middle</label>
                <input pInputText [value]="m()?.middleName ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-4">
                <label class="text-sm text-muted-color">Last</label>
                <input pInputText [value]="m()?.lastName ?? ''" readonly class="w-full" />
              </div>
            </div>
          </div>

          <!-- Contact -->
          <div class="col-span-12">
            <div class="grid grid-cols-12 gap-3">
              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Personal Email</label>
                <input pInputText [value]="m()?.emailPersonnel ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Marital Status</label>
                <input pInputText [value]="m()?.maritalStatus ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Phone (Personal)</label>
                <input pInputText [value]="m()?.personnelPhoneNumber ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Phone (Home)</label>
                <input pInputText [value]="m()?.domicilePhoneNumber ?? ''" readonly class="w-full" />
              </div>
            </div>
          </div>

          <!-- Esprit Enrollment -->
          <div class="col-span-12">
            <div class="grid grid-cols-12 gap-3">
              <div class="col-span-12 md:col-span-4">
                <label class="text-sm">Department</label>
                <input pInputText [value]="m()?.department ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-4">
                <label class="text-sm">Speciality</label>
                <input pInputText [value]="m()?.speciality ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-4">
                <label class="text-sm">Current Class</label>
                <input pInputText [value]="m()?.currentClass ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Entry Date</label>
                <input pInputText [value]="m()?.entryDate ?? ''" readonly class="w-full" />
              </div>
              <div class="col-span-12 md:col-span-6">
                <label class="text-sm">Expected Exit Date</label>
                <input pInputText [value]="m()?.expectedExitDate ?? ''" readonly class="w-full" />
              </div>
            </div>
          </div>
        </div>
      </p-card>
    </div>
  </div>
  `
})
export class StudentProfileViewComponent implements OnInit {
  private api = inject(StudentSelfService);
  private messages = inject(MessageService);

  m = signal<StudentSelfView | null>(null);
  avatarUrl = computed(() => this.m()?.avatarUrl || 'assets/images/placeholder-avatar.png');

  ngOnInit(): void {
    this.api.getMe().subscribe({
      next: (res) => this.m.set(res),
      error: (err) => this.messages.add({ severity: 'error', summary: 'Load failed', detail: err?.error?.message || 'Unexpected error' })
    });
  }

  imgFallback(ev: any) { ev.target.style.display = 'none'; }
}
