import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface StudentSelfView {
  // read-only identity
  email: string;
  firstName: string;
  middleName: string | null;
  lastName: string;
  studentIdentifier: string | null;

  // user editable
  emailPersonnel: string | null;
  maritalStatus: string | null;
  personnelPhoneNumber: string | null;
  domicilePhoneNumber: string | null;

  // profile
  avatarKey: string | null;      // stored object key (from backend profile)
  avatarUrl: string | null;      // presigned GET url (computed by backend)

  // esprit enrollment (SORTANT)
  entryDate: string | null;        // yyyy-MM-dd
  expectedExitDate: string | null; // yyyy-MM-dd
  department: string | null;       // enum name (Field)
  speciality: string | null;       // enum name (OptionCode)
  currentClass: string | null;
}

export interface StudentSelfUpdate {
  emailPersonnel?: string | null;
  maritalStatus?: string | null;
  personnelPhoneNumber?: string | null;
  domicilePhoneNumber?: string | null;

  // NOTE: avatarKey is NOT needed here anymore since upload saves it server-side
  entryDate?: string | null;
  expectedExitDate?: string | null;
  department?: string | null;
  speciality?: string | null;
  currentClass?: string | null;
}

@Injectable({ providedIn: 'root' })
export class StudentSelfService {
  private http = inject(HttpClient);

  private readonly meBase = '/api/me/student';
  private readonly avatarUploadUrl = '/api/student/profile/photo/upload'; // existing controller you already have

  // ---- profile data (GET/PUT) ----
  getMe(): Observable<StudentSelfView> {
    return this.http.get<StudentSelfView>(this.meBase);
  }

  updateMe(payload: StudentSelfUpdate): Observable<StudentSelfView> {
    return this.http.put<StudentSelfView>(this.meBase, payload);
  }

  // ---- avatar upload (multipart -> returns { key, url, contentType }) ----
  uploadAvatar(file: File): Observable<{ key: string; url: string | null; contentType: string }> {
    const form = new FormData();
    form.append('file', file);
    return this.http.post<{ key: string; url: string | null; contentType: string }>(this.avatarUploadUrl, form);
  }
}
