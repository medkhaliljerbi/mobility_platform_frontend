import { inject } from '@angular/core';
import { CanActivateChildFn, Router, UrlTree } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { catchError, map, of } from 'rxjs';

type StudentProfileDto = {
  semester1Grade?: number | null;
  semester2Grade?: number | null;
  semester3Grade?: number | null;
  semester4Grade?: number | null;
  semester5Grade?: number | null;
  maxCertificates?: number | null;
  photoObjectKey?: string | null;  // present in your backend DTO
};

// decide if we consider the student “complete” for gating purposes
function isProfileComplete(p: StudentProfileDto | null): boolean {
  // use your own rule; with current API we at least have photoObjectKey
  // AND/OR use a local flag once the student finishes the setup screen
  const localFlag = localStorage.getItem('student_profile_completed') === 'true';
  return !!(p?.photoObjectKey) || localFlag;
}

export const EnsureStudentSetupGuard: CanActivateChildFn = (_route, state) => {
  const router = inject(Router);
  const http = inject(HttpClient);

  const url = state.url || '/';

  // always allow auth pages and the setup page itself
  if (url.startsWith('/auth')) return true;
  if (url.startsWith('/student/setup')) return true;

  // Probe the existing student endpoint to detect role and completion
  return http.get<StudentProfileDto>('/api/student/profile', { withCredentials: true }).pipe(
    map((profile) => {
      // 200 → this user is a STUDENT
      return isProfileComplete(profile)
        ? true
        : (router.parseUrl('/student/setup') as UrlTree);
    }),
    catchError((err) => {
      const status = err?.status ?? err?.error?.status;

      if (status === 401) {
        // not logged in / expired
        return of(router.parseUrl('/auth/login') as UrlTree);
      }
      if (status === 403 || status === 404) {
        // not a student → do not block
        return of(true);
      }
      // for other backend errors, don't brick the app
      return of(true);
    })
  );
};
