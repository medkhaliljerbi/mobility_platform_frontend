export interface RosterRow {
  espritId: string;
  firstName: string;
  middleName?: string | null;
  lastName: string;
  espritEmail: string;
  phone?: string | null;
}
