export interface LoadStats {
  parsed: number;
  skippedExistingUsers: number;
  inserted: number;
  updated: number;
}
