// src/app/core/auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from 'src/environments/environment';
export interface LoginRequest {
  email: string;
  password: string;
}
export interface RawLoginResponse {
  token?: string;
  accessToken?: string;
  jwt?: string;
  id_token?: string;
  message?: string;
  // ... autres champs éventuels
}

@Injectable({ providedIn: 'root' })
export class AuthService {

  private base = `${environment.apiBase}auth`;
  private readonly json = new HttpHeaders({
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  });

  constructor(private http: HttpClient) {}

  signup(body: any): Observable<any> {
    return this.http.post<any>(`${this.base}/signup`, body, { headers: this.json });
  }

  login(body: LoginRequest): Observable<{ token?: string; raw: RawLoginResponse }> {
    // adapte ici si ton endpoint est /auth/signin :
    return this.http
      .post<RawLoginResponse>(`${this.base}/signin`, body, { headers: this.json })
      .pipe(
        map((raw) => {
          const token = raw.accessToken ?? raw.token ?? raw.jwt ?? raw.id_token ?? undefined;
          return { token, raw };
        })
      );
  }
}
