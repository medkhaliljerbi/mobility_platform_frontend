// src/app/core/services/admin-users.services.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { User } from '../models/user.model';
import { UserUpsertRequest } from '../dto/user-upsert-request';
import { UploadRosterResponse } from '../dto/upload-roster.response';
import { RosterRow } from '../models/roster-row.model';
import { InviteResult } from '../dto/invite-result.dto';

@Injectable({ providedIn: 'root' })
export class AdminUserService {
  private base = `${environment.apiBase}api/admin/users`;

  constructor(private http: HttpClient) {}

  // ---- dynamic token from localStorage / sessionStorage ----
  private authHeaders(): HttpHeaders {
    // try localStorage first, fallback to sessionStorage
    const token =
      localStorage.getItem('auth_token') || sessionStorage.getItem('auth_token');

    if (!token) {
      console.warn('No auth token found in storage');
      return new HttpHeaders(); // calls will fail with 401 until user logs in
    }

    return new HttpHeaders().set('Authorization', `Bearer ${token}`);
  }

  // ---- API calls ----
  getAll(): Observable<User[]> {
    return this.http.get<User[]>(this.base, { headers: this.authHeaders() });
  }

  getById(id: number): Observable<User> {
    return this.http.get<User>(`${this.base}/${id}`, { headers: this.authHeaders() });
  }

  patchUpdate(id: number, body: Partial<UserUpsertRequest>): Observable<User> {
    return this.http.patch<User>(`${this.base}/${id}`, body, { headers: this.authHeaders() });
  }

  setActive(id: number, active: boolean): Observable<User> {
    return this.http.patch<User>(`${this.base}/${id}/active`, { active }, { headers: this.authHeaders() });
  }

  resetPassword(id: number, newPassword: string): Observable<void> {
    const body = { newPassword };
    return this.http.patch<void>(`${this.base}/${id}/password`, body, { headers: this.authHeaders() });
  }
  //////////////// invite esprit student and fill in and flushes out rooster staging ///////////////
  uploadRosterAndLoad(
    file: File,
    opts: { useCase?: string; groupId?: string; filename?: string; contentType?: string; load?: boolean } = {}
  ): Observable<UploadRosterResponse> {
    const form = new FormData();
    form.append('file', file, opts.filename || file.name);
    form.append('useCase', opts.useCase ?? 'roster');
    form.append('groupId', opts.groupId ?? 'staging');
    form.append('load', String(opts.load ?? true));
    if (opts.filename) form.append('filename', opts.filename);
    if (opts.contentType) form.append('contentType', opts.contentType);

    return this.http.post<UploadRosterResponse>(`${this.base}/roster/upload`, form, { headers: this.authHeaders() });
  }

  listStaging(): Observable<RosterRow[]> {
    return this.http.get<RosterRow[]>(`${this.base}/roster/staging`, { headers: this.authHeaders() });
  }

  clearStaging(): Observable<void> {
    return this.http.delete<void>(`${this.base}/roster/staging`, { headers: this.authHeaders() });
  }

  inviteAll(dryRun = false): Observable<InviteResult> {
    return this.http.post<InviteResult>(`${this.base}/roster/invite?dryRun=${dryRun}`, {}, { headers: this.authHeaders() });
  }
   inviteOne(email: string): Observable<any> {
    const params = new HttpParams().set('email', email);
    return this.http.post(`${this.base}/roster/invite-one`, null, { headers: this.authHeaders(), params });
  }
}
